<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Add Email Details</h1>

    <form method="post" action="send-mail">
        @csrf
        <label for="">USer Email:</label>
        <input type="text" name="to" placeholder="Enter your email"><br><br>
        <label for="">Subject:</label>
        <input type="text" name="subject" placeholder="Enter your subject">
        <br><br>
        <label>Message</label>
        <textarea type="text" name="message" placeholder="your message"></textarea>
        <br><br>
        <button>Send E-mail</button>


    </form>

</body>
</html>
