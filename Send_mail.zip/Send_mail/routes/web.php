<?php

use App\Http\Controllers\MailController;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
});

Route::post('send-mail',[MailController::class, 'sendmail']);
// Route::get('smail',[MailController::class, 'sendmail']);
Route::view('send-mail','send-email');
